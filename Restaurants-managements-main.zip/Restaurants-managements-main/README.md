# Restaurants-managements
That Restaurants managements project is done according to the fiverr client requirements.
